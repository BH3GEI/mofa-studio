Opaque type encapsulating a Windows SID.
